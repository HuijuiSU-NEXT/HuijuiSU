# 一键隐藏 v1.4（78 整合 · 恋雪）

| 模块 | id |
|---|---|
| Zygisk Next 1.5.2 | zygisksu |
| LSPosed 2.2.1 | zygisk_lsposed |
| HMA-OSS UID3.1 | hma_oss_zygisk |
| OhMyKeymint R1 1.3.6 | oh_my_keymint |
| PlayIntegrityFix-Dates v4.9 | playintegrityfix |

内置：HMA 管理端 APK、keybox.xml、7 个检测软件（detect/）、春秋修复脚本（scripts/）、默认 HMA 配置（hma/config.json）。

## WebUI 功能

- 补装 / 应用设置、重新导入配置、重扫名单、刷新状态、查看日志
- **替换 keybox.xml**（填路径 → 写入 OhMyKeymint 模块目录 + 运行时目录）
- **导入 HMA 配置**（填路径 → 写入 /data/misc/hide_my_applist_*/config.json → 自动同步 denylist 黑白名单）
- **安装检测软件**（批量安装 detect/ 下 7 个 APK）
- **关闭无线调试**（adb_wifi_enabled=0）
- **春秋修复工具**（把 JinBei 脚本复制到 /sdcard/Download，用 MT 以 root 运行）

## 安装

Magisk / KernelSU / HuijuiSU 管理器 → 模块 → 从本地安装 → 重启。

## 注意

- 检测软件装了 7 个（含春秋），不装可以不点那个按钮
- 春秋修复脚本是交互式菜单，必须用 MT 以 root 运行，WebUI 只负责复制
- Zygisk Next 设置（仅还原挂载 / 匿名内存 / ZN 链接器）在 config.sh 里，装完自动应用、每次开机再应用
- 仅供自己本机使用，别外传
