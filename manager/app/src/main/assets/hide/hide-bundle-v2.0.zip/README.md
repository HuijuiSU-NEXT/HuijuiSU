# 一键隐藏 v2.0（hide_bundle）

| 顺序 | 模块 | id | 说明 |
|---|---|---|---|
| 1 | Zygisk Next 1.5.2 | `zygisksu` | 独立 Zygisk 实现 |
| 2 | LSPosed 2.2.1 | `zygisk_lsposed` | Xposed 框架 |
| 3 | HMA-OSS UID3.1 (arm64) | `hma_oss_zygisk` | 隐藏应用列表 |
| 4 | OhMyKeymint R1 1.3.6 | `oh_my_keymint` | KeyMint / Play 完整性 |
| + | HMA 管理端 APK | `org.frknkrc44.hma_oss` | HMA 界面 |

装完还会自动：

1. **装 HMA 管理端**（`apk/hma-oss.apk`，没有就按 `HMA_APK_URL` 下载）
2. **导入 HMA 配置** → `/data/misc/hide_my_applist_<rand>/config.json`（system:system 0600）
3. **导入 keybox** → OhMyKeymint（`/data/misc/keystore/omk/keybox.xml`，keystore 1017，0600）
4. **应用 Zygisk Next 设置**：`enforce-denylist just_umount`、`memory-type anonymous`、`linker builtin`
5. **扫描应用生成黑白名单**并同步 Magisk denylist

## 常用命令

```sh
su -c 'sh /data/adb/modules/hide_bundle/oneclick.sh'            # 补装 + 重导 + 应用设置
su -c 'sh /data/adb/modules/hide_bundle/oneclick.sh --force'    # 四个模块全部重装
su -c 'sh /data/adb/modules/hide_bundle/oneclick.sh --reimport' # 强制重导 HMA 配置和 keybox
su -c 'sh /data/adb/modules/hide_bundle/applist.sh'             # 看黑白名单
su -c 'sh /data/adb/modules/hide_bundle/applist.sh --apply'     # 重扫并写 denylist
su -c 'cat /data/adb/hide_bundle.log'
```

## 名单

```
lists/generated_blacklist.txt   自动扫（每次开机重刷）
lists/generated_whitelist.txt   自动扫
lists/blacklist.txt             你手写，不覆盖
lists/whitelist.txt             你手写，不覆盖
lists/applied.txt               脚本记录，用于 denylist 同步删除
```

## 注意

- 只能从管理器装（recovery 没 magiskd）
- LSPosed 安装要联网申请 license
- 加进 denylist 的应用 Zygisk 不注入 → HMA/LSPosed 在那几个应用里也失效；`just_umount` 模式下两者应该都能用（未实测）
- 导入只在第一次做，之后你在 HMA / OhMyKeymint 界面里的修改不会被覆盖；想重导用 `--reimport`
- OhMyKeymint / Zygisk Next 的许可都有限制，本包仅供自己本机使用，不要外传
