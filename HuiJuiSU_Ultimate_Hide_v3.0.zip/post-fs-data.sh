#!/system/bin/sh
MODDIR=${0%/*}
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 1; done

# 如果有 SUSFS，就调用内核级隐藏
if command -v ksu_susfs >/dev/null 2>&1; then
    ksu_susfs add_sus_path /data/adb/modules
    ksu_susfs add_sus_path /data/adb/ksu
    ksu_susfs add_sus_mount /data/adb
fi

# 属性伪装
resetprop ro.boot.verifiedbootstate green
resetprop ro.boot.flash.locked 1
resetprop ro.debuggable 0
resetprop ro.adb.secure 1
resetprop ro.build.type user
resetprop ro.build.tags release-keys
